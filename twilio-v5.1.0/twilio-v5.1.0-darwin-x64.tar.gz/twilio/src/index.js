module.exports = require('@oclif/core');
