const { PostInstallDisplayManager } = require('./src/services/post-install-utility');

new PostInstallDisplayManager().displayMessage();
